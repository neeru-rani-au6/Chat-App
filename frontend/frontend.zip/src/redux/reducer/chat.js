import { ALLMESSAGE } from '../type';

const initialState = {
    messages: []
};

const ChatReducer = (state = initialState, action) => {
    const { type, payload } = action;

    switch (type) {
        case ALLMESSAGE:
            return Object.assign(state, payload);
        default:
            return state;
    }
}

export default ChatReducer;